<?php
class User_Model
{
    private $nama = "Guru PRL";
    public function getUser()
    {
        return $this->nama;
    }
}
