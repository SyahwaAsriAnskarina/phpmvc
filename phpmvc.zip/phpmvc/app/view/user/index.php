<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial- scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Halaman <?= $data['judul']; ?></title>
</head>

<body>
    <div class="container mt-5">
        <div class="card" style="max-width: 560px;">
            <div class="row no-gutters">
                <div class="col-md-4">
                <img src="img/gambar6.jpg" class="card-img" alt="...">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <h5 class="card-title">SYAHWA ASRI ANSKARINA</h5>
                        
                        <p class="card-text">NAMA          : SYAHWA ASRI ANSKARINA</p>
                        <p class="card-text">JENIS_KELAMIN : PEREMPUAN</p>
                        <p class="card-text">KELAS         : XII RPL C</p>
                        <p class="card-text">UMUR          : 18 TAHUN</p>
                    </div>
                </div>
            </div>
        </div>
</body>

</html>